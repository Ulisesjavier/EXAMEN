<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include "funciones.inc"?>
</head>
<body>
<?php
             $cobDepartamentos = $_POST("cobDepartamentos");
           ?>

               <tr>
                   <th>Nombre</th>
                   <th>Puesto</th>
                   <th>FechaContratacion</th>
                   <th>Nombre Surcusal</th>
                   <th>Direcion Surcusal</th>
                   <th>Ciudad surcusal</th>
               </tr>
               <?php
                   foreach ( $Empleado as $Sucursal => $grupos) { ?>
                       <tr>
                           <td>
                               <?php echo f_nombreApellidoEmpleado($codEmpleado); ?>
                           </td>
                           <td>
                               <?php f_puestoEmpleado($codEmpleado); ?>
                           </td>
                               <?php f_fechaContratacionEmpleado($codEmpleado); ?>
                           </td>
                           <td>
                               <?php  f_nombreSucursal($codSucursal); ?>
                           </td>
                           <td>
                               <?php f_direccionSucursal($codSucursal); ?>
                           </td>
                           <td>
                               <?php f_ciudadSucursal($codSucursal); ?>
                           </td>
                       </tr>
                   <?php
                   }
               ?>
           </table>
           <?php
    ?>
</body>
</html>